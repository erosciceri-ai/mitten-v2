"""Arranque de prueba web: sensores reales, sin audio ni Wi-Fi."""
import sys
sys.path.insert(0, '/mitten_web')
import web_start
web_start.main()
