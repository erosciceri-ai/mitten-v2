"""Referencia MPU temporal al arrancar; no guarda calibracion en flash."""
import time
import math
import network
from machine import ADC, Pin, I2C
from sensors import MPU6050
from hardware import create_hardware
from runtime import asyncio, main_loop


def main():
    # GPIO25 es ADC2: no activar Wi-Fi durante la prueba.
    network.WLAN(network.STA_IF).active(False)
    network.WLAN(network.AP_IF).active(False)
    i2c = I2C(0, sda=Pin(21), scl=Pin(22), freq=100000)
    addresses = [a for a in i2c.scan() if a in (0x68, 0x69)]
    if len(addresses) != 1:
        raise OSError('Se espera un MPU6050 en 0x68 o 0x69')
    mpu = MPU6050(addresses[0])
    mpu.initialize(i2c)
    time.sleep_ms(100)
    # Media circular para conservar la referencia junto al limite +/-180 grados.
    sx = cx = sy = cy = 0.0
    for _ in range(50):
        x, y, _ = mpu.read_acceleration()
        x *= math.pi / 180
        y *= math.pi / 180
        sx += math.sin(x)
        cx += math.cos(x)
        sy += math.sin(y)
        cy += math.cos(y)
        time.sleep_ms(20)
    if math.sqrt(sx*sx + cx*cx) / 50 < 0.98 or math.sqrt(sy*sy + cy*cy) / 50 < 0.98:
        raise ValueError('MPU inestable: reiniciar con el sensor inmovil')
    board = {
        'flex_pins': [32, 33, 34, 35, 25],
        'adc_attenuation': ADC.ATTN_11DB,
        'i2c_id': 0, 'sda_pin': 21, 'scl_pin': 22,
        'mpu_address': addresses[0],
        'mpu_offsets': [math.atan2(sx, cx) * 180 / math.pi,
                        math.atan2(sy, cy) * 180 / math.pi],
        'protocol_transport': 'stdio', 'audio_enabled': False,
    }
    transport, sensors, player = create_hardware(board)
    asyncio.run(main_loop(transport, sensor_manager=sensors, dfplayer=player))
